let data = [
 {
  id: 0,
  name: 'john doe',
  job: 'developer',
  text: `A biography, or simply bio, is a detailed description of a person's life.It involves more than just the basic facts like education, work, relationships, and death; it portrays a person's experience of these life events. Unlike a profile or curriculum vitae (résumé), a biography presents a subject's life story, highlighting various aspects of his or her life, including intimate details of experience, and may include an analysis of the subject's personality.`,
  favorites: ['eat', 'drink', 'sleep'],
  img: 'img/team-1.jpg'
 },
 {
  id: 1,
  name: 'tom orange',
  job: 'designer',
  text: `A biography, or simply bio, is a detailed description of a person's life.It involves more than just the basic facts like education, work, relationships, and death; it portrays a person's experience of these life events. Unlike a profile or curriculum vitae (résumé), a biography presents a subject's life story, highlighting various aspects of his or her life, including intimate details of experience, and may include an analysis of the subject's personality.`,
  favorites: ['paint', 'draw', 'run'],
  img: 'img/team-2.jpg'
 },
 {
  id: 2,
  name: 'albert cupid',
  job: 'accountant',
  text: `A biography, or simply bio, is a detailed description of a person's life.It involves more than just the basic facts like education, work, relationships, and death; it portrays a person's experience of these life events. Unlike a profile or curriculum vitae (résumé), a biography presents a subject's life story, highlighting various aspects of his or her life, including intimate details of experience, and may include an analysis of the subject's personality.`,
  favorites: ['math', 'physics', 'more math'],
  img: 'img/team-3.jpg'
 },
 {
  id: 4,
  name: 'dog hugo',
  job: 'intern',
  text: `A biography, or simply bio, is a detailed description of a person's life.It involves more than just the basic facts like education, work, relationships, and death; it portrays a person's experience of these life events. Unlike a profile or curriculum vitae (résumé), a biography presents a subject's life story, highlighting various aspects of his or her life, including intimate details of experience, and may include an analysis of the subject's personality.`,
  favorites: ['bark', 'run', 'bite'],
  img: 'img/team-4.jpg'
 }]